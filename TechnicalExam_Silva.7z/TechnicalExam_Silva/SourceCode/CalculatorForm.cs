﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.InteropServices;

namespace TechnicalExercise_Silva
{
    public partial class calculatorForm : Form
    {
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn
            (
                int nLeft,
                int nTop,
                int nRight,
                int nBottom,
                int nWidthEllipse,
                int nHeightEllipse
            );
        Double resultValue = 0;
        Double firstValue = 0;
        Double secondValue = 0;
        Double lastValue = 0;
        Double memoryResult = 0;
        int counter = 1;
        String operationPerformed = "";
        String historyAction = "";
        bool isOperationPerformed = false;
        bool isOperationSuccess = false;
        bool isMemoryPerformed = false;
        bool isOperationContinuous = false;
        bool isAnotherOperation = false;
        bool isClearOperationContinuous = false;
        bool isSquaredOperation = false;

        DataTable table = new DataTable();

        Stack st = new Stack();

        public calculatorForm()
        {
            InitializeComponent();
        }

        private void button_click(object sender, EventArgs e)
        {
            Button button = (Button)sender;

            if (textBox_Result.Text == "∞" || textBox_Result.Text == "Cannot divide by zero" || textBox_Result.Text == "Result is undefined")
            {
                label_CurrentOperation.Text = "";
                textBox_Result.Text = button.Text;
                comboBox_Operators.Text = "";
                label_CurrentOperation.Text = "";
                EnableMemoryAndOperatorButton();
                reset();
                firstValue = 0;
                operationPerformed = "";
                resultValue = 0;
                return;
            }
            else if (textBox_Result.Text == "0" || (isOperationPerformed) || (isMemoryPerformed)||(isSquaredOperation))
            {
                textBox_Result.Clear();
            }
            if (isOperationSuccess)
            {
                textBox_Result.Clear();
                label_CurrentOperation.Text = "";
                isAnotherOperation = true;
            }
            if (button.Text == ".")
            {
                if (!textBox_Result.Text.Contains("."))
                {
                    if (textBox_Result.Text == "")
                    {
                        textBox_Result.Text = "0";
                        textBox_Result.Text = textBox_Result.Text + button.Text;
                    }
                    else
                    {
                        textBox_Result.Text = textBox_Result.Text + button.Text;

                    }
                }
            }
            else
            {
                textBox_Result.Text = textBox_Result.Text + button.Text;
            }
            reset();
            if(isClearOperationContinuous)
            {
                isOperationContinuous = true;
            }
            else
            {
                isClearOperationContinuous = false;
            }
        }

        private void comboBox_Operators_SelectedIndexChanged(object sender, EventArgs e)
        {
            operationPerformed = comboBox_Operators.Text;
            firstValue = Double.Parse(textBox_Result.Text);
            label_CurrentOperation.Text = firstValue + " " + operationPerformed;
            reset();
            isOperationPerformed = true;
        }

        private void button_Clear_Click(object sender, EventArgs e)
        {
            if (textBox_Result.Text == "∞" || textBox_Result.Text == "Cannot divide by zero" || textBox_Result.Text == "Result is undefined")
            {
                label_CurrentOperation.Text = "";
                comboBox_Operators.Text = "";
                label_CurrentOperation.Text = "";
                EnableMemoryAndOperatorButton();
                reset();
                textBox_Result.Text = "0";
                firstValue = 0;
                operationPerformed = "";
                resultValue = 0;
                return;
            }
            if (resultValue != 0)
                label_CurrentOperation.Text = "";

            textBox_Result.Text = "0";
            comboBox_Operators.Text = "";
     
            reset();
            isClearOperationContinuous = true;
            isOperationContinuous = true;
        }

        private void button_Delete_Click(object sender, EventArgs e)
        {
            if (textBox_Result.Text == "∞" || textBox_Result.Text == "Cannot divide by zero" || textBox_Result.Text == "Result is undefined")
            {
                label_CurrentOperation.Text = "";
                comboBox_Operators.Text = "";
                label_CurrentOperation.Text = "";
                EnableMemoryAndOperatorButton();
                reset();
                textBox_Result.Text = "0";
                firstValue = 0;
                operationPerformed = "";
                resultValue = 0;
                return;
            }
            textBox_Result.Text = "0";
            resultValue = 0;
            label_CurrentOperation.Text = "";
            comboBox_Operators.Text = "";
            operationPerformed = "";
            historyAction = "Clear";
            table.Rows.Add(counter, historyAction, resultValue);
            counter++;
            clearHistoryButton.Visible = true;
            reset();
        }

        private void button_Equal_Click(object sender, EventArgs e)
        {
            try
            {
                historyAction = "";
                if (textBox_Result.Text == "Result is undefined" || textBox_Result.Text == "Cannot divide by zero")
                {
                    textBox_Result.Clear();
                    comboBox_Operators.Text = "";
                    label_CurrentOperation.Text = "";
                    reset();
                    EnableMemoryAndOperatorButton();
                    textBox_Result.Text = "0";
                    operationPerformed = "";
                    resultValue = 0;
                    return;
                }
                else if (isOperationContinuous && operationPerformed != "")
                {
                    if (isClearOperationContinuous)
                    {
                        firstValue = Double.Parse(textBox_Result.Text);
                    }
                    else
                    {
                        lastValue = secondValue;
                        firstValue = resultValue;
                    }
                }
                else if (isAnotherOperation && operationPerformed != "")
                {
                    lastValue = secondValue;
                    secondValue = Double.Parse(textBox_Result.Text);
                    if (isAnotherOperation)
                    {
                        firstValue = secondValue;
                        secondValue = lastValue;
                    }
                }
                else
                {
                    secondValue = Double.Parse(textBox_Result.Text);
                }

                switch (operationPerformed)
                {
                    case "+":
                        textBox_Result.Text = (firstValue + secondValue).ToString();
                        comboBox_Operators.Text = "";
                        resultValue = double.Parse(textBox_Result.Text);
                        historyAction = "Add";
                        break;
                    case "-":
                        textBox_Result.Text = (firstValue - secondValue).ToString();
                        comboBox_Operators.Text = "";
                        resultValue = double.Parse(textBox_Result.Text);
                        historyAction = "Subtract";
                        break;
                    case "x":
                        textBox_Result.Text = (firstValue * secondValue).ToString();
                        comboBox_Operators.Text = "";
                        resultValue = double.Parse(textBox_Result.Text);
                        historyAction = "Multiply";
                        if (textBox_Result.Text == "-0")
                        {
                            textBox_Result.Text = "0";
                            resultValue = 0; 
                        }
                        break;
                    case "÷":
                        if (firstValue == 0 && secondValue == 0)
                        {
                            textBox_Result.Text = "Result is undefined";
                            comboBox_Operators.Text = "";
                            historyAction = "Divide";
                            table.Rows.Add(counter, historyAction, secondValue);
                            counter++;
                            historyAction = "Equals";
                            table.Rows.Add(counter, historyAction, "Error!");
                            counter++;
                            DisableMemoryAndOperatorButton();
                            return;
                        }
                        else if (secondValue == 0)
                        {
                            textBox_Result.Text = "Cannot divide by zero";
                            comboBox_Operators.Text = "";
                            historyAction = "Divide";
                            table.Rows.Add(counter, historyAction, secondValue);
                            counter++;
                            historyAction = "Equals";
                            table.Rows.Add(counter, historyAction, "Error!");
                            counter++;
                            DisableMemoryAndOperatorButton();
                            return;
                        }
                        else
                        {
                            textBox_Result.Text = (firstValue / secondValue).ToString();
                            comboBox_Operators.Text = "";
                            resultValue = double.Parse(textBox_Result.Text);
                            historyAction = "Divide";
                        }
                        break;
                    default:
                        break;
                }
                if (resultValue == 0 && operationPerformed == "")
                {
                    if (historyLabel.Font.Underline)
                        clearHistoryButton.Visible = true;

                    label_CurrentOperation.Text = secondValue.ToString() + "=";
                    historyAction = "Equals";
                    table.Rows.Add(counter, historyAction, secondValue);
                    counter++;
                }
                else if (isOperationContinuous && !isClearOperationContinuous)
                {
                    if (historyLabel.Font.Underline)
                        clearHistoryButton.Visible = true;

                    label_CurrentOperation.Text = firstValue.ToString() + operationPerformed + lastValue.ToString() + " " + "=";
                    table.Rows.Add(counter, historyAction, firstValue);
                    counter++;
                    table.Rows.Add(counter, historyAction, secondValue);
                    counter++;
                    historyAction = "Equals";
                    table.Rows.Add(counter, historyAction, resultValue);
                    counter++;
                }
                else
                {
                    if (historyLabel.Font.Underline)
                        clearHistoryButton.Visible = true;

                    label_CurrentOperation.Text = firstValue.ToString() + operationPerformed + secondValue.ToString() + " " + "=";
                    table.Rows.Add(counter, historyAction, firstValue);
                    counter++;
                    table.Rows.Add(counter, historyAction, secondValue);
                    counter++;
                    historyAction = "Equals";
                    table.Rows.Add(counter, historyAction, resultValue);
                    counter++;

                }

                isOperationSuccess = true;
                isAnotherOperation = false;
                isOperationContinuous = true;
                isClearOperationContinuous = false;
            }
            catch (FormatException)
            {
                MessageBox.Show("Invalid Input");
            }

        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Shift == true && e.KeyCode == Keys.Oemplus)
            {
                e.Handled = true;
                comboBox_Operators.SelectedIndex = 0;
            }
            else if (e.Shift == true && e.KeyCode == Keys.D8)
            {
                e.Handled = true;
                comboBox_Operators.SelectedIndex = 2;
            }
            else if (e.KeyCode == Keys.Oem2 && e.Shift == false)
            {
                e.Handled = true;
                comboBox_Operators.SelectedIndex = 4;
            }
            else if (e.KeyCode == Keys.OemMinus && e.Shift == false)
            {
                e.Handled = true;
                comboBox_Operators.SelectedIndex = 1;
            }
            else if (e.KeyCode == Keys.Oemplus && e.Shift == false)
            {
                e.Handled = true;
                button_Equal.PerformClick();
            }
            else if (e.KeyCode == Keys.D0 && e.Shift == false)
            {
                e.Handled = true;
                button0.PerformClick();
            }
            else if (e.KeyCode == Keys.D1 && e.Shift == false)
            {
                e.Handled = true;
                button1.PerformClick();
            }
            else if (e.KeyCode == Keys.D2 && e.Shift == false)
            {
                e.Handled = true;
                button2.PerformClick();
            }
            else if (e.KeyCode == Keys.D3 && e.Shift == false)
            {
                e.Handled = true;
                button3.PerformClick();
            }
            else if (e.KeyCode == Keys.D4 && e.Shift == false)
            {
                e.Handled = true;
                button4.PerformClick();
            }
            else if (e.KeyCode == Keys.D5 && e.Shift == false)
            {
                e.Handled = true;
                button5.PerformClick();
            }
            else if (e.KeyCode == Keys.D6 && e.Shift == false)
            {
                e.Handled = true;
                button6.PerformClick();
            }
            else if (e.KeyCode == Keys.D7 && e.Shift == false)
            {
                e.Handled = true;
                button7.PerformClick();
            }
            else if (e.KeyCode == Keys.D8 && e.Shift == false)
            {
                e.Handled = true;
                button8.PerformClick();
            }
            else if (e.KeyCode == Keys.D9 && e.Shift == false)
            {
                e.Handled = true;
                button9.PerformClick();
            }
            else if (e.KeyCode == Keys.C && e.Control == true)
            {
                e.Handled = true;
                copyToolStripMenuItem.PerformClick();
            }
            else if (e.KeyCode == Keys.V && e.Control == true)
            {
                e.Handled = true;
                pasteToolStripMenuItem.PerformClick();
            }
        }

        private void PosNegButton_Click(object sender, EventArgs e)
        {
            if (textBox_Result.Text.StartsWith("-"))
            {
                textBox_Result.Text = textBox_Result.Text.Substring(1);
            }
            else if (!string.IsNullOrEmpty(textBox_Result.Text) && decimal.Parse(textBox_Result.Text) != 0)
            {
                textBox_Result.Text = "-" + textBox_Result.Text;
            }
        }

        private void clearHistoryButton_Click(object sender, EventArgs e)
        {
            clearHistoryButton.Visible = false;
            table.Clear();
            counter = 1;
        }

        private void memoryPlusButton_Click(object sender, EventArgs e)
        {
            if(memoryLabel.Font.Underline)
                memoryTrashButton.Visible = true;

            isMemoryPerformed = true;
            memoryClearButton.Enabled = true;
            memoryRecallButton.Enabled = true;
            memoryResult = memoryResult + Double.Parse(textBox_Result.Text);
            st.Push(memoryResult);


            if (lbMemoryDisplay.Items.Count > 0)
            {
                lbMemoryDisplay.Items[lbMemoryDisplay.TopIndex] = memoryResult;
            }
            else
            {
                lbMemoryDisplay.Items.Insert(0, memoryResult);
                st.Push(memoryResult);
            }
        }

        private void memoryMinusButton_Click(object sender, EventArgs e)
        {
            if (memoryLabel.Font.Underline)
                memoryTrashButton.Visible = true;

            isMemoryPerformed = true;
            memoryClearButton.Enabled = true;
            memoryRecallButton.Enabled = true;
            memoryResult = memoryResult - Double.Parse(textBox_Result.Text);
            if (lbMemoryDisplay.Items.Count > 0)
            {
                lbMemoryDisplay.Items[lbMemoryDisplay.TopIndex] = memoryResult;
            }
            else
            {
                lbMemoryDisplay.Items.Insert(0, memoryResult);
                st.Push(memoryResult);
            }
        }

        private void memoryStoreButton_Click(object sender, EventArgs e)
        {
            if(memoryLabel.Font.Underline)
                memoryTrashButton.Visible = true;

            isMemoryPerformed = true;
            memoryClearButton.Enabled = true;
            memoryRecallButton.Enabled = true;
            memoryResult = Double.Parse(textBox_Result.Text);
            lbMemoryDisplay.Items.Insert(0, memoryResult);
            st.Push(memoryResult);
        }

        private void memory_clearButton_Click(object sender, EventArgs e)
        {
            memoryResult = 0;
            isMemoryPerformed = false;
            memoryClearButton.Enabled = false;
            memoryRecallButton.Enabled = false;
            memoryTrashButton.Visible = false;
            lbMemoryDisplay.Items.Clear();
            st.Clear();
        }

        private void memoryRecallButton_Click(object sender, EventArgs e)
        {
            isMemoryPerformed = true;
            textBox_Result.Text = lbMemoryDisplay.Items[lbMemoryDisplay.TopIndex].ToString();

        }

        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox_Result.Text = "0";
            resultValue = 0;
            label_CurrentOperation.Text = "";
            comboBox_Operators.Text = "";
            operationPerformed = "";
            reset();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(textBox_Result.Text);
        }

        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Clipboard.ContainsText(TextDataFormat.Text))
                textBox_Result.Text = Clipboard.GetText(TextDataFormat.Text);
        }

        private void calculatorForm_Load(object sender, EventArgs e)
        {
            RoundedButton();
            historyLabel.Font = new Font(historyLabel.Font.Name, historyLabel.Font.SizeInPoints, FontStyle.Underline);
            memoryLabel.Font = new Font(memoryLabel.Font.Name, memoryLabel.Font.SizeInPoints, FontStyle.Regular);
            lbMemoryDisplay.Visible = false;
            table.Columns.Add("Id", typeof(int));
            table.Columns.Add("History Action", typeof(string));
            table.Columns.Add("History Value", typeof(string));
            historyGridView.DataSource = table;
        }

        private void exportToTextToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveDialog = new SaveFileDialog();
            saveDialog.Filter = "Text File|*.txt";
            var result = saveDialog.ShowDialog();
            if (result != DialogResult.OK)
                return;
            StringBuilder builder = new StringBuilder();
            int rowcount = historyGridView.Rows.Count;
            int columncount = historyGridView.Columns.Count;

            for (int i = 0; i < rowcount - 1; i++)
            {
                List<string> cols = new List<string>();
                for (int j = 0; j <= columncount - 1; j++)
                {
                    cols.Add(historyGridView.Rows[i].Cells[j].Value.ToString());
                }
                builder.AppendLine(string.Join("\t", cols.ToArray()));
            }
            File.WriteAllText(saveDialog.FileName, builder.ToString());
            MessageBox.Show(@"Text file was created.");
        }

        private void importToTextToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openDialog = new OpenFileDialog();
            openDialog.Filter = "Text File|*.txt";
            var result = openDialog.ShowDialog();

            if (result != DialogResult.OK)
                return;
            try
            {
                table.Clear();
                string[] textData = File.ReadAllLines(openDialog.FileName);
                for (int i = 0; i < textData.Length; i++)
                    table.Rows.Add(textData[i].Split('\t'));
                historyGridView.DataSource = table;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Could not read file from disk.  Original error: " + ex.Message);
            }
        }

        private void exportToXMLToolStripMenuItem_Click(object sender, EventArgs e)
        {

            SaveFileDialog saveDialog = new SaveFileDialog();
            saveDialog.Filter = "XML|*.xml";
            var result = saveDialog.ShowDialog();
            if (result != DialogResult.OK)
                return;
            StringBuilder builder = new StringBuilder();
            int rowcount = historyGridView.Rows.Count;
            int columncount = historyGridView.Columns.Count;

            for (int i = 0; i < rowcount - 1; i++)
            {
                List<string> cols = new List<string>();
                for (int j = 0; j <= columncount - 1; j++)
                {
                    cols.Add(historyGridView.Rows[i].Cells[j].Value.ToString());
                }
                builder.AppendLine(string.Join("\t", cols.ToArray()));
            }
            File.WriteAllText(saveDialog.FileName, builder.ToString());
            MessageBox.Show(@"XML file was created.");
        }
        public void reset()
        {
            isOperationSuccess = false;
            isMemoryPerformed = false;
            isClearOperationContinuous = false;
            isOperationPerformed = false;
            isOperationContinuous = false;
            isAnotherOperation = false;
            isSquaredOperation = false;
        }
        public void RoundedButton()
        {
            button1.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, button1.Width, button1.Height, 10, 10));
            button2.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, button2.Width, button2.Height, 10, 10));
            button3.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, button3.Width, button3.Height, 10, 10));
            button4.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, button4.Width, button4.Height, 10, 10));
            button5.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, button5.Width, button5.Height, 10, 10));
            button6.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, button6.Width, button6.Height, 10, 10));
            button7.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, button7.Width, button7.Height, 10, 10));
            button8.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, button8.Width, button8.Height, 10, 10));
            button9.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, button9.Width, button9.Height, 10, 10));
            button0.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, button0.Width, button0.Height, 10, 10)); 
            button_Clear.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, button_Clear.Width, button_Clear.Height, 10, 10));
            button_decimal.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, button_decimal.Width, button_decimal.Height, 10, 10));
            button_Equal.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, button_Equal.Width, button_Equal.Height, 10, 10));
            memoryClearButton.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, memoryClearButton.Width, memoryClearButton.Height, 10, 10));
            memoryMinusButton.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, memoryMinusButton.Width, memoryMinusButton.Height, 10, 10));
            memoryPlusButton.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, memoryPlusButton.Width, memoryPlusButton.Height, 10, 10));
            memoryRecallButton.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, memoryRecallButton.Width, memoryRecallButton.Height, 10, 10));
            memoryStoreButton.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, memoryStoreButton.Width, memoryStoreButton.Height, 10, 10));
            PosNegButton.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, PosNegButton.Width, PosNegButton.Height, 10, 10));
            button_Delete.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, PosNegButton.Width, PosNegButton.Height, 10, 10));
            squaredButton.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, PosNegButton.Width, PosNegButton.Height, 10, 10));
            comboBox_Operators.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, comboBox_Operators.Width, comboBox_Operators.Height, 10, 10));
            textBox_Result.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, textBox_Result.Width, textBox_Result.Height, 10, 10));
        }
        private void historyLabel_Click(object sender, EventArgs e)
        {

            historyLabel.Font = new Font(historyLabel.Font.Name, historyLabel.Font.SizeInPoints, FontStyle.Underline);
            memoryLabel.Font = new Font(memoryLabel.Font.Name, memoryLabel.Font.SizeInPoints, FontStyle.Regular);
            historyGridView.Visible = true;
            lbMemoryDisplay.Visible = false;
            memoryTrashButton.Visible = false;
            if(historyGridView.Rows.Count > 1)
            {
                clearHistoryButton.Visible = true;
            }
        }

        private void memoryLabel_Click(object sender, EventArgs e)
        {
            memoryLabel.Font = new Font(memoryLabel.Font.Name, memoryLabel.Font.SizeInPoints, FontStyle.Underline);
            historyLabel.Font = new Font(historyLabel.Font.Name, historyLabel.Font.SizeInPoints, FontStyle.Regular);
            historyGridView.Visible = false;
            lbMemoryDisplay.Visible = true;
            clearHistoryButton.Visible = false;
            if (lbMemoryDisplay.Items.Count > 0)
            {
                memoryTrashButton.Visible = true;
            }
        }

        private void memoryTrashButton_Click(object sender, EventArgs e)
        {
            memoryTrashButton.Visible = false;
            memoryClearButton.Enabled = false;
            memoryRecallButton.Enabled = false;
            lbMemoryDisplay.Items.Clear();
        }
        public void DisableMemoryAndOperatorButton()
        {
            memoryClearButton.Enabled = false;
            memoryMinusButton.Enabled = false;
            memoryPlusButton.Enabled = false;
            memoryRecallButton.Enabled = false;
            memoryStoreButton.Enabled = false;
            comboBox_Operators.Enabled = false;
            PosNegButton.Enabled = false;
            squaredButton.Enabled = false;
            button_decimal.Enabled = false;
        }
        public void EnableMemoryAndOperatorButton()
        {
            if(lbMemoryDisplay.Items.Count > 0)
            {
                memoryRecallButton.Enabled = true;
                memoryClearButton.Enabled = true;

            }
            memoryMinusButton.Enabled = true;
            memoryPlusButton.Enabled = true;
            memoryStoreButton.Enabled = true;
            comboBox_Operators.Enabled = true;
            PosNegButton.Enabled = true;
            squaredButton.Enabled = true;
            button_decimal.Enabled = true;
        }

        private void squaredButton_Click(object sender, EventArgs e)
        {
            if(textBox_Result.Text == "∞")
            {
                DisableMemoryAndOperatorButton();
                return;
            }
            comboBox_Operators.Text = "";

            label_CurrentOperation.Text = ("sqrt(" + textBox_Result.Text + ")");
            historyAction = "Sqrt";
            table.Rows.Add(counter, historyAction, textBox_Result.Text);
            counter++;
            isSquaredOperation = true;
            textBox_Result.Text = Math.Pow(Double.Parse(textBox_Result.Text),2).ToString();
            historyAction = "Equal";
            table.Rows.Add(counter, historyAction, textBox_Result.Text);
            counter++;
        }
    }
}
